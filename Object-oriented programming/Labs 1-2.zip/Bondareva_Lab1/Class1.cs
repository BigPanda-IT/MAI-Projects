﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormApp
{
    internal class Class1
    {
        public string l1, l2, l3, l4, l5, l6, l7;
        public int l8;
        public Class1(string l1, string l2, string l3, string l4, string l5, string l6, string l7, int l8)
        {
            this.l1 = l1;
            this.l2 = l2;
            this.l3 = l3;
            this.l4 = l4;
            this.l5 = l5;
            this.l6 = l6;
            this.l7 = l7;
            this.l8 = l8;

        }

    }
}
