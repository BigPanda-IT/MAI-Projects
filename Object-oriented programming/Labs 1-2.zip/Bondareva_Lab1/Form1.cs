﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            form2 = new Form2();
        }
        Form2 form2;

        private void label3_Click(object sender, EventArgs e) {}

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string l1 = textBox1.Text;
                string l2 = textBox2.Text;
                string l3 = textBox3.Text;
                string l4 = textBox4.Text;
                string l5 = textBox5.Text;

                string l6 = textBox6.Text;
                string l7 = textBox8.Text;

                int l6_1 = Convert.ToInt32(l6);
                int l7_1 = Convert.ToInt32(l7);

                int l8 = l6_1 - l7_1;
                textBox7.Text = l8.ToString();


                Class1 class1 = new Class1(l1, l2, l3, l4, l5, l6, l7, l8);

            }

            catch
            {
                MessageBox.Show("Ошибка.Повторите попытку.Возможно,осуществлен неверный ввод данных");
            }
        }

        private void label9_Click(object sender, EventArgs e)  { }

        private void textBox5_TextChanged(object sender, EventArgs e) { }

        private void textBox2_TextChanged(object sender, EventArgs e) { }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Txt = this.textBox7.Text;

            form2.ShowDialog();
            Application.Exit();

        }

        private void label6_Click(object sender, EventArgs e) { }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
