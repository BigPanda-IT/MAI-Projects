﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormApp
{
    public partial class Form2 : Form
    {
        public string Txt
        {
            get { return textBox2.Text; }
            set { textBox2.Text = value; }
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void form2_closing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)  { }

        private void button1_Click(object sender, EventArgs e)
        {
            string l9 = textBox3.Text;
            int l9_1 = Convert.ToInt32(l9);

            string l10 = textBox2.Text;
            int l10_1 = Convert.ToInt32(l10);

            int l11 = l9_1 + l10_1;
            textBox1.Text = l11.ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e) { }

        private void textBox3_TextChanged(object sender, EventArgs e) { }

        private void label3_Click(object sender, EventArgs e) { }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
